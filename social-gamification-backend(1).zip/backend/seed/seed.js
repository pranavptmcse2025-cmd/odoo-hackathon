/**
 * Seeds the database with dummy data that mirrors the shape/values already
 * used as mock data in the React frontend (src/data/csrData.js and
 * src/data/employees.js), so once the frontend is wired to this API the
 * numbers on screen won't jump around.
 *
 * Run with: npm run seed
 */
require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("../config/db");

const Employee = require("../models/Employee");
const Activity = require("../models/Activity");
const Participation = require("../models/Participation");
const Badge = require("../models/Badge");
const Reward = require("../models/Reward");
const Challenge = require("../models/Challenge");
const Redemption = require("../models/Redemption");

const badgesData = [
  { badgeName: "Eco Beginner", description: "Awarded at 100 XP", icon: "🌱", requiredPoints: 100 },
  { badgeName: "Green Warrior", description: "Awarded at 250 XP", icon: "♻️", requiredPoints: 250 },
  { badgeName: "Climate Hero", description: "Awarded at 500 XP", icon: "🌍", requiredPoints: 500 },
  { badgeName: "Earth Guardian", description: "Awarded at 1000 XP", icon: "🏆", requiredPoints: 1000 },
];

const rewardsData = [
  { rewardName: "Reusable Bottle", description: "Insulated steel water bottle", requiredXP: 150, available: true },
  { rewardName: "Coffee Voucher", description: "Free coffee for a week", requiredXP: 250, available: true },
  { rewardName: "Gift Card", description: "₹1000 e-commerce gift card", requiredXP: 600, available: true },
  { rewardName: "Company Recognition", description: "Featured on the internal newsletter", requiredXP: 800, available: true },
  { rewardName: "Plant Sapling Kit", description: "Take-home sapling + planter kit", requiredXP: 120, available: true },
];

const employeesData = [
  { employeeId: "EMP001", name: "Ananya Rao", department: "Sustainability", email: "ananya.rao@ecosphere.io", xp: 3840, totalPoints: 3840 },
  { employeeId: "EMP002", name: "Rahul Mehta", department: "Operations", email: "rahul.mehta@ecosphere.io", xp: 3620, totalPoints: 3620 },
  { employeeId: "EMP003", name: "Priya Nair", department: "HR", email: "priya.nair@ecosphere.io", xp: 3410, totalPoints: 3410 },
  { employeeId: "EMP004", name: "Karthik Iyer", department: "Manufacturing", email: "karthik.iyer@ecosphere.io", xp: 3105, totalPoints: 3105 },
  { employeeId: "EMP005", name: "Sneha Kapoor", department: "Marketing", email: "sneha.kapoor@ecosphere.io", xp: 2980, totalPoints: 2980 },
  { employeeId: "EMP006", name: "Vikram Singh", department: "Logistics", email: "vikram.singh@ecosphere.io", xp: 2750, totalPoints: 2750 },
  { employeeId: "EMP007", name: "Divya Menon", department: "Finance", email: "divya.menon@ecosphere.io", xp: 2590, totalPoints: 2590 },
  { employeeId: "EMP008", name: "Arjun Reddy", department: "IT & Operations", email: "arjun.reddy@ecosphere.io", xp: 2410, totalPoints: 2410 },
];

const activitiesData = [
  {
    title: "Tree Plantation Drive",
    description: "Community tree plantation to restore the local green cover.",
    category: "Environment",
    icon: "tree",
    location: "City Park",
    date: new Date("2026-06-12"),
    maximumParticipants: 150,
    participants: 84,
    status: "Completed",
    pointsAwarded: 80,
  },
  {
    title: "Beach Cleanup Marathon",
    description: "Shoreline cleanup drive to remove plastic waste.",
    category: "Environment",
    icon: "wave",
    location: "Marina Beach",
    date: new Date("2026-06-28"),
    maximumParticipants: 100,
    participants: 56,
    status: "Completed",
    pointsAwarded: 50,
  },
  {
    title: "Blood Donation Camp",
    description: "On-campus blood donation drive with the regional blood bank.",
    category: "Health",
    icon: "droplet",
    location: "Head Office Auditorium",
    date: new Date("2026-07-05"),
    maximumParticipants: 200,
    participants: 132,
    status: "Ongoing",
    pointsAwarded: 100,
  },
  {
    title: "Education Drive for Kids",
    description: "Volunteer teaching session for underprivileged children.",
    category: "Education",
    icon: "book",
    location: "Community Center",
    date: new Date("2026-07-20"),
    maximumParticipants: 80,
    participants: 47,
    status: "Upcoming",
    pointsAwarded: 60,
  },
];

const challengesData = [
  {
    challengeName: "30-Day Zero Waste Challenge",
    description: "Log a waste-reduction action every day for 30 days.",
    startDate: new Date("2026-07-01"),
    endDate: new Date("2026-07-31"),
    points: 200,
    status: "Active",
  },
  {
    challengeName: "Cycle to Work Week",
    description: "Commute by bicycle for at least 5 working days.",
    startDate: new Date("2026-08-01"),
    endDate: new Date("2026-08-07"),
    points: 120,
    status: "Upcoming",
  },
];

async function seed() {
  await connectDB();

  console.log("Clearing existing collections...");
  await Promise.all([
    Employee.deleteMany({}),
    Activity.deleteMany({}),
    Participation.deleteMany({}),
    Badge.deleteMany({}),
    Reward.deleteMany({}),
    Challenge.deleteMany({}),
    Redemption.deleteMany({}),
  ]);

  console.log("Inserting badges & rewards...");
  const badges = await Badge.insertMany(badgesData);

  await Reward.insertMany(rewardsData);

  console.log("Inserting activities...");
  await Activity.insertMany(activitiesData);

  console.log("Inserting challenges...");
  await Challenge.insertMany(challengesData);

  console.log("Inserting employees & assigning badges...");
  for (const empData of employeesData) {
    const earnedBadges = badges.filter((b) => empData.xp >= b.requiredPoints).map((b) => b._id);
    await Employee.create({ ...empData, badges: earnedBadges, badgeCount: earnedBadges.length });
  }

  // Recompute ranks based on XP
  const employees = await Employee.find().sort({ xp: -1 });
  const bulkOps = employees.map((emp, index) => ({
    updateOne: { filter: { _id: emp._id }, update: { rank: index + 1 } },
  }));
  if (bulkOps.length) await Employee.bulkWrite(bulkOps);

  console.log("Seeding complete!");
  await mongoose.connection.close();
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});
