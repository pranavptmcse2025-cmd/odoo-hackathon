const mongoose = require("mongoose");

const badgeSchema = new mongoose.Schema(
  {
    badgeName: { type: String, required: true, unique: true, trim: true },
    description: { type: String, default: "" },
    icon: { type: String, default: "🏅" },
    requiredPoints: { type: Number, required: true }, // XP threshold
  },
  { timestamps: true }
);

module.exports = mongoose.model("Badge", badgeSchema);
