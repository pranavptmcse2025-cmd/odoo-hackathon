const mongoose = require("mongoose");

// Bonus collection (not in original spec) to keep an audit trail of reward redemptions.
const redemptionSchema = new mongoose.Schema(
  {
    employeeId: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
    rewardId: { type: mongoose.Schema.Types.ObjectId, ref: "Reward", required: true },
    xpSpent: { type: Number, required: true },
    redeemedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Redemption", redemptionSchema);
