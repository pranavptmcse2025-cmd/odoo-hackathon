const mongoose = require("mongoose");

const challengeSchema = new mongoose.Schema(
  {
    challengeName: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    points: { type: Number, required: true, default: 100 },
    status: {
      type: String,
      enum: ["Upcoming", "Active", "Completed"],
      default: "Upcoming",
    },
    participants: [
      {
        employeeId: { type: mongoose.Schema.Types.ObjectId, ref: "Employee" },
        joinedDate: { type: Date, default: Date.now },
        completed: { type: Boolean, default: false },
        completedDate: { type: Date, default: null },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Challenge", challengeSchema);
