const mongoose = require("mongoose");

const participationSchema = new mongoose.Schema(
  {
    employeeId: { type: mongoose.Schema.Types.ObjectId, ref: "Employee", required: true },
    activityId: { type: mongoose.Schema.Types.ObjectId, ref: "Activity", required: true },
    status: {
      type: String,
      enum: ["Joined", "Completed", "Cancelled"],
      default: "Joined",
    },
    joinedDate: { type: Date, default: Date.now },
    completedDate: { type: Date, default: null },
    pointsEarned: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// An employee can only have one active participation record per activity
participationSchema.index({ employeeId: 1, activityId: 1 }, { unique: true });

module.exports = mongoose.model("Participation", participationSchema);
