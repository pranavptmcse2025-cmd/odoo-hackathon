const mongoose = require("mongoose");

const activitySchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    category: {
      type: String,
      enum: ["Environment", "Health", "Education", "Community", "Other"],
      default: "Other",
    },
    icon: { type: String, default: "tree" }, // maps to frontend iconMap: tree | wave | droplet | book
    location: { type: String, default: "" },
    date: { type: Date, required: true },
    maximumParticipants: { type: Number, default: 100 },
    participants: { type: Number, default: 0 }, // running count of joined employees
    status: {
      type: String,
      enum: ["Upcoming", "Ongoing", "Completed", "Cancelled"],
      default: "Upcoming",
    },
    pointsAwarded: { type: Number, required: true, default: 50 }, // XP given on completion
  },
  { timestamps: { createdAt: "createdAt", updatedAt: "updatedAt" } }
);

module.exports = mongoose.model("Activity", activitySchema);
