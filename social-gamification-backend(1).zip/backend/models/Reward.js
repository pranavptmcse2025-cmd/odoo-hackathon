const mongoose = require("mongoose");

const rewardSchema = new mongoose.Schema(
  {
    rewardName: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    requiredXP: { type: Number, required: true },
    available: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Reward", rewardSchema);
