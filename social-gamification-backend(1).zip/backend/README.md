# EcoSphere — Social & Gamification Module

Backend module for the **Social & Gamification** pillar of the EcoSphere ESG
Management Platform (Odoo Hackathon). Built with **Node.js + Express +
MongoDB (Mongoose)** following the **MVC** pattern. This module owns its own
REST API only — it does not touch the existing React frontend.

## Stack
- Node.js / Express.js
- MongoDB / Mongoose
- CORS enabled for the frontend origin

## Folder Structure
```
backend/
  config/db.js                 MongoDB connection
  controllers/
    socialController.js        Employees, Activities, Participation, Dashboard
    gamificationController.js  Badges, Rewards, Leaderboard, Challenges
  models/
    Employee.js
    Activity.js
    Participation.js
    Badge.js
    Reward.js
    Challenge.js
    Redemption.js               (bonus: audit trail for reward redemptions)
  routes/
    socialRoutes.js
    gamificationRoutes.js
  utils/badgeEngine.js          Badge-eligibility logic, shared by activities & challenges
  seed/seed.js                  Dummy data matching the frontend's mock data
  server.js
```

## Setup

```bash
cd backend
npm install
cp .env.example .env      # then edit MONGO_URI / PORT / CLIENT_URL if needed
npm run seed               # populates dummy employees, activities, badges, rewards, challenges
npm run dev                 # starts on http://localhost:5000 (needs nodemon, included in devDependencies)
# or: npm start
```

MongoDB must be running locally (or point `MONGO_URI` at Atlas). No API key
or auth is required for this module.

## API Reference

All responses follow:
```json
{ "success": true, "message": "...", "data": ... }
```

### Employees
| Method | Route | Body |
|---|---|---|
| GET | `/api/employees` | — |
| POST | `/api/employees` | `{ employeeId, name, department, email }` |
| PUT | `/api/employees/:id` | any updatable fields |
| DELETE | `/api/employees/:id` | — |

### CSR Activities
| Method | Route | Body |
|---|---|---|
| GET | `/api/activities` | optional `?status=&category=` query filters |
| POST | `/api/activities` | `{ title, description, category, icon, location, date, maximumParticipants, pointsAwarded }` |
| PUT | `/api/activities/:id` | any updatable fields |
| DELETE | `/api/activities/:id` | — |

### Participation
| Method | Route | Body |
|---|---|---|
| POST | `/api/participate` | `{ employeeId, activityId }` — join an activity |
| GET | `/api/participation/:employeeId` | list an employee's joined/completed activities |
| PUT | `/api/participation/:id` | `{ action: "cancel" }` or `{ action: "complete" }` |

Completing a participation is the core gamification trigger:
1. Adds `activity.pointsAwarded` to the employee's XP & totalPoints
2. Checks all badge thresholds and auto-assigns any newly-earned badges
3. Recalculates leaderboard ranks

Example response from `PUT /api/participation/:id` with `{ "action": "complete" }`:
```json
{
  "success": true,
  "message": "Activity completed successfully",
  "xpEarned": 50,
  "badgeUnlocked": "Green Warrior",
  "badgesUnlocked": ["Green Warrior"],
  "data": { "...participation record..." }
}
```

### Badges
| Method | Route | Body |
|---|---|---|
| GET | `/api/badges` | — |
| POST | `/api/badges` | `{ badgeName, description, icon, requiredPoints }` |

### Rewards
| Method | Route | Body |
|---|---|---|
| GET | `/api/rewards` | — |
| POST | `/api/redeem` | `{ employeeId, rewardId }` — validates sufficient XP, deducts XP, logs a `Redemption` |

### Leaderboard
| Method | Route |
|---|---|
| GET | `/api/leaderboard` | Top 10 employees ranked by XP (tie-break: badge count) |

Shaped to drop straight into the existing `Leaderboard.jsx`:
```json
{
  "success": true,
  "data": [
    { "rank": 1, "name": "Ananya Rao", "department": "Sustainability", "xp": 3840, "badges": ["🏆 Earth Guardian", "🌍 Climate Hero"] }
  ]
}
```

### Challenges
| Method | Route | Body |
|---|---|---|
| GET | `/api/challenges` | — |
| POST | `/api/challenges` | `{ challengeName, description, startDate, endDate, points }` |
| PUT | `/api/challenges/:id` | any updatable fields |
| DELETE | `/api/challenges/:id` | — |
| POST | `/api/challenges/:id/join` | `{ employeeId }` |
| POST | `/api/challenges/:id/complete` | `{ employeeId }` — awards XP + checks badges |

### Dashboard
| Method | Route |
|---|---|
| GET | `/api/dashboard/social` |

```json
{
  "success": true,
  "data": {
    "totalActivities": 4,
    "completedActivities": 2,
    "activeEmployees": 8,
    "totalXPAwarded": 24705,
    "mostActiveDepartment": "Sustainability",
    "topEmployee": { "name": "Ananya Rao", "department": "Sustainability", "xp": 3840, "badgeCount": 4 }
  }
}
```

## Business Rules Implemented
- An employee cannot join the same activity twice while a `Joined` record exists.
- Completing an activity requires an existing `Joined` participation record.
- Redemption is blocked if `employee.xp < reward.requiredXP`.
- Badge assignment is automatic and cumulative — an employee keeps every badge whose threshold they've crossed.
- Leaderboard `rank` is recalculated on every activity completion.
- Activities enforce `maximumParticipants`.

## Frontend Integration Notes
The existing frontend currently reads from `src/data/csrData.js` and
`src/data/employees.js` mock files. This API's response shapes intentionally
mirror those objects (`title/date/participants/points/status/icon` for
activities, `rank/name/department/xp/badges` for the leaderboard) so that
swapping the mock imports for `axios.get('/api/activities')` /
`axios.get('/api/leaderboard')` calls is close to a drop-in replacement.
`icon` values (`tree`, `wave`, `droplet`, `book`) match the `iconMap` already
defined in `Social.jsx`.

CORS is enabled for `CLIENT_URL` (defaults to `http://localhost:5173`, Vite's
default port).
