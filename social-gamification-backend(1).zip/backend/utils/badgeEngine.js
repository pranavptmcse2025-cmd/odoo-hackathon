const Badge = require("../models/Badge");

/**
 * Checks an employee's current XP against all badges in the system and
 * assigns any newly-earned badges. Returns the list of NEWLY unlocked badges
 * (empty array if none). Mutates employee.badges / employee.badgeCount but
 * does NOT save the employee document — caller is responsible for save().
 */
async function checkAndAssignBadges(employee) {
  const allBadges = await Badge.find().sort({ requiredPoints: 1 });
  const alreadyOwned = new Set(employee.badges.map((id) => id.toString()));
  const newlyUnlocked = [];

  for (const badge of allBadges) {
    const owns = alreadyOwned.has(badge._id.toString());
    if (!owns && employee.xp >= badge.requiredPoints) {
      employee.badges.push(badge._id);
      newlyUnlocked.push(badge);
    }
  }

  employee.badgeCount = employee.badges.length;
  return newlyUnlocked;
}

module.exports = { checkAndAssignBadges };
