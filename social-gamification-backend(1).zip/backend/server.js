require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const socialRoutes = require("./routes/socialRoutes");
const gamificationRoutes = require("./routes/gamificationRoutes");

const app = express();

// ---- middleware ----
app.use(cors({ origin: process.env.CLIENT_URL || "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ---- routes ----
app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "EcoSphere Social & Gamification API is running",
  });
});

app.use("/api", socialRoutes);
app.use("/api", gamificationRoutes);

// ---- 404 handler ----
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// ---- global error handler ----
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: "Internal server error" });
});

const PORT = process.env.PORT || 5000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Social & Gamification API listening on port ${PORT}`);
  });
});

module.exports = app;
