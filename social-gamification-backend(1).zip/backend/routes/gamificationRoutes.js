const express = require("express");
const router = express.Router();
const gamification = require("../controllers/gamificationController");

// Badges
router.get("/badges", gamification.getBadges);
router.post("/badges", gamification.createBadge);

// Rewards
router.get("/rewards", gamification.getRewards);
router.post("/redeem", gamification.redeemReward);

// Leaderboard
router.get("/leaderboard", gamification.getLeaderboard);

// Challenges
router.get("/challenges", gamification.getChallenges);
router.post("/challenges", gamification.createChallenge);
router.put("/challenges/:id", gamification.updateChallenge);
router.delete("/challenges/:id", gamification.deleteChallenge);
router.post("/challenges/:id/join", gamification.joinChallenge);
router.post("/challenges/:id/complete", gamification.completeChallenge);

module.exports = router;
