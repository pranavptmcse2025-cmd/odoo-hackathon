const express = require("express");
const router = express.Router();
const social = require("../controllers/socialController");

// Employees
router.get("/employees", social.getEmployees);
router.post("/employees", social.createEmployee);
router.put("/employees/:id", social.updateEmployee);
router.delete("/employees/:id", social.deleteEmployee);

// CSR Activities
router.get("/activities", social.getActivities);
router.post("/activities", social.createActivity);
router.put("/activities/:id", social.updateActivity);
router.delete("/activities/:id", social.deleteActivity);

// Participation
router.post("/participate", social.joinActivity);
router.get("/participation/:employeeId", social.getParticipationByEmployee);
router.put("/participation/:id", social.updateParticipation);

// Dashboard
router.get("/dashboard/social", social.getSocialDashboard);

module.exports = router;
