const mongoose = require("mongoose");
const Employee = require("../models/Employee");
const Badge = require("../models/Badge");
const Reward = require("../models/Reward");
const Redemption = require("../models/Redemption");
const Challenge = require("../models/Challenge");

const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

// =========================================================
// BADGES
// =========================================================

// GET /badges
exports.getBadges = async (req, res) => {
  try {
    const badges = await Badge.find().sort({ requiredPoints: 1 });
    res.status(200).json({ success: true, count: badges.length, data: badges });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /badges
exports.createBadge = async (req, res) => {
  try {
    const { badgeName, requiredPoints } = req.body;
    if (!badgeName || requiredPoints === undefined) {
      return res.status(400).json({ success: false, message: "badgeName and requiredPoints are required" });
    }

    const badge = await Badge.create(req.body);
    res.status(201).json({ success: true, message: "Badge created successfully", data: badge });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ success: false, message: "A badge with this name already exists" });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

// =========================================================
// REWARDS
// =========================================================

// GET /rewards
exports.getRewards = async (req, res) => {
  try {
    const rewards = await Reward.find().sort({ requiredXP: 1 });
    res.status(200).json({ success: true, count: rewards.length, data: rewards });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /redeem  { employeeId, rewardId }
exports.redeemReward = async (req, res) => {
  try {
    const { employeeId, rewardId } = req.body;
    if (!employeeId || !rewardId || !isValidId(employeeId) || !isValidId(rewardId)) {
      return res.status(400).json({ success: false, message: "Valid employeeId and rewardId are required" });
    }

    const employee = await Employee.findById(employeeId);
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });

    const reward = await Reward.findById(rewardId);
    if (!reward) return res.status(404).json({ success: false, message: "Reward not found" });
    if (!reward.available) return res.status(400).json({ success: false, message: "Reward is currently unavailable" });

    if (employee.xp < reward.requiredXP) {
      return res.status(400).json({
        success: false,
        message: `Insufficient XP. Requires ${reward.requiredXP} XP, employee has ${employee.xp} XP`,
      });
    }

    employee.xp -= reward.requiredXP;
    await employee.save();

    const redemption = await Redemption.create({
      employeeId,
      rewardId,
      xpSpent: reward.requiredXP,
    });

    res.status(200).json({
      success: true,
      message: "Reward redeemed successfully",
      xpRemaining: employee.xp,
      data: redemption,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// =========================================================
// LEADERBOARD
// =========================================================

// GET /leaderboard
// Ranks by highest XP, tie-broken by most activities completed then most badges.
exports.getLeaderboard = async (req, res) => {
  try {
    const employees = await Employee.find()
      .populate("badges", "badgeName icon")
      .sort({ xp: -1, badgeCount: -1 })
      .limit(10);

    const leaderboard = employees.map((emp, index) => ({
      rank: index + 1,
      employeeId: emp._id,
      name: emp.name,
      department: emp.department,
      xp: emp.xp,
      totalPoints: emp.totalPoints,
      badgeCount: emp.badgeCount,
      badges: emp.badges.map((b) => `${b.icon || "🏅"} ${b.badgeName}`),
    }));

    res.status(200).json({ success: true, count: leaderboard.length, data: leaderboard });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// =========================================================
// CHALLENGES
// =========================================================

// GET /challenges
exports.getChallenges = async (req, res) => {
  try {
    const challenges = await Challenge.find().sort({ startDate: 1 });
    res.status(200).json({ success: true, count: challenges.length, data: challenges });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /challenges
exports.createChallenge = async (req, res) => {
  try {
    const { challengeName, startDate, endDate, points } = req.body;
    if (!challengeName || !startDate || !endDate || points === undefined) {
      return res.status(400).json({ success: false, message: "challengeName, startDate, endDate and points are required" });
    }

    const challenge = await Challenge.create(req.body);
    res.status(201).json({ success: true, message: "Challenge created successfully", data: challenge });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /challenges/:id
exports.updateChallenge = async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid challenge id" });

    const challenge = await Challenge.findByIdAndUpdate(id, req.body, { new: true, runValidators: true });
    if (!challenge) return res.status(404).json({ success: false, message: "Challenge not found" });

    res.status(200).json({ success: true, message: "Challenge updated successfully", data: challenge });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /challenges/:id
exports.deleteChallenge = async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid challenge id" });

    const challenge = await Challenge.findByIdAndDelete(id);
    if (!challenge) return res.status(404).json({ success: false, message: "Challenge not found" });

    res.status(200).json({ success: true, message: "Challenge deleted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /challenges/:id/join  { employeeId }
exports.joinChallenge = async (req, res) => {
  try {
    const { id } = req.params;
    const { employeeId } = req.body;
    if (!isValidId(id) || !isValidId(employeeId)) {
      return res.status(400).json({ success: false, message: "Valid challenge id and employeeId are required" });
    }

    const challenge = await Challenge.findById(id);
    if (!challenge) return res.status(404).json({ success: false, message: "Challenge not found" });

    const employee = await Employee.findById(employeeId);
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });

    const alreadyJoined = challenge.participants.some((p) => p.employeeId.toString() === employeeId);
    if (alreadyJoined) {
      return res.status(409).json({ success: false, message: "Employee has already joined this challenge" });
    }

    challenge.participants.push({ employeeId });
    await challenge.save();

    res.status(201).json({ success: true, message: "Joined challenge successfully", data: challenge });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /challenges/:id/complete  { employeeId }
exports.completeChallenge = async (req, res) => {
  try {
    const { id } = req.params;
    const { employeeId } = req.body;
    if (!isValidId(id) || !isValidId(employeeId)) {
      return res.status(400).json({ success: false, message: "Valid challenge id and employeeId are required" });
    }

    const challenge = await Challenge.findById(id);
    if (!challenge) return res.status(404).json({ success: false, message: "Challenge not found" });

    const participantEntry = challenge.participants.find((p) => p.employeeId.toString() === employeeId);
    if (!participantEntry) {
      return res.status(400).json({ success: false, message: "Employee must join the challenge before completing it" });
    }
    if (participantEntry.completed) {
      return res.status(400).json({ success: false, message: "Challenge already completed by this employee" });
    }

    const employee = await Employee.findById(employeeId);
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });

    participantEntry.completed = true;
    participantEntry.completedDate = new Date();

    const xpEarned = challenge.points;
    employee.xp += xpEarned;
    employee.totalPoints += xpEarned;

    const { checkAndAssignBadges } = require("../utils/badgeEngine");
    const newlyUnlocked = await checkAndAssignBadges(employee);

    await Promise.all([challenge.save(), employee.save()]);

    res.status(200).json({
      success: true,
      message: "Challenge completed successfully",
      xpEarned,
      badgeUnlocked: newlyUnlocked.length ? newlyUnlocked[newlyUnlocked.length - 1].badgeName : null,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
