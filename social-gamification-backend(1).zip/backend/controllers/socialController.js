const mongoose = require("mongoose");
const Employee = require("../models/Employee");
const Activity = require("../models/Activity");
const Participation = require("../models/Participation");
const Badge = require("../models/Badge");
const { checkAndAssignBadges } = require("../utils/badgeEngine");

// ---------- helpers ----------
const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

// =========================================================
// EMPLOYEES
// =========================================================

// GET /employees
exports.getEmployees = async (req, res) => {
  try {
    const employees = await Employee.find().populate("badges", "badgeName icon").sort({ xp: -1 });
    res.status(200).json({ success: true, count: employees.length, data: employees });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /employees
exports.createEmployee = async (req, res) => {
  try {
    const { employeeId, name, department, email } = req.body;
    if (!employeeId || !name || !department || !email) {
      return res.status(400).json({ success: false, message: "employeeId, name, department and email are required" });
    }

    const existing = await Employee.findOne({ $or: [{ employeeId }, { email }] });
    if (existing) {
      return res.status(409).json({ success: false, message: "Employee with this employeeId or email already exists" });
    }

    const employee = await Employee.create({ employeeId, name, department, email });
    res.status(201).json({ success: true, message: "Employee created successfully", data: employee });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /employees/:id
exports.updateEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid employee id" });

    const employee = await Employee.findByIdAndUpdate(id, req.body, { new: true, runValidators: true });
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });

    res.status(200).json({ success: true, message: "Employee updated successfully", data: employee });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /employees/:id
exports.deleteEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid employee id" });

    const employee = await Employee.findByIdAndDelete(id);
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });

    res.status(200).json({ success: true, message: "Employee deleted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// =========================================================
// CSR ACTIVITIES
// =========================================================

// GET /activities
exports.getActivities = async (req, res) => {
  try {
    const { status, category } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (category) filter.category = category;

    const activities = await Activity.find(filter).sort({ date: 1 });
    res.status(200).json({ success: true, count: activities.length, data: activities });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /activities
exports.createActivity = async (req, res) => {
  try {
    const { title, date, pointsAwarded } = req.body;
    if (!title || !date || pointsAwarded === undefined) {
      return res.status(400).json({ success: false, message: "title, date and pointsAwarded are required" });
    }

    const activity = await Activity.create(req.body);
    res.status(201).json({ success: true, message: "Activity created successfully", data: activity });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /activities/:id
exports.updateActivity = async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid activity id" });

    const activity = await Activity.findByIdAndUpdate(id, req.body, { new: true, runValidators: true });
    if (!activity) return res.status(404).json({ success: false, message: "Activity not found" });

    res.status(200).json({ success: true, message: "Activity updated successfully", data: activity });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /activities/:id
exports.deleteActivity = async (req, res) => {
  try {
    const { id } = req.params;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid activity id" });

    const activity = await Activity.findByIdAndDelete(id);
    if (!activity) return res.status(404).json({ success: false, message: "Activity not found" });

    // Clean up any participation records tied to this activity
    await Participation.deleteMany({ activityId: id });

    res.status(200).json({ success: true, message: "Activity deleted successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// =========================================================
// PARTICIPATION
// =========================================================

// POST /participate  { employeeId, activityId }
exports.joinActivity = async (req, res) => {
  try {
    const { employeeId, activityId } = req.body;
    if (!employeeId || !activityId || !isValidId(employeeId) || !isValidId(activityId)) {
      return res.status(400).json({ success: false, message: "Valid employeeId and activityId are required" });
    }

    const [employee, activity] = await Promise.all([
      Employee.findById(employeeId),
      Activity.findById(activityId),
    ]);
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });
    if (!activity) return res.status(404).json({ success: false, message: "Activity not found" });

    const existing = await Participation.findOne({ employeeId, activityId });
    if (existing && existing.status !== "Cancelled") {
      return res.status(409).json({ success: false, message: "Employee has already joined this activity" });
    }

    if (activity.participants >= activity.maximumParticipants) {
      return res.status(400).json({ success: false, message: "Activity has reached maximum participants" });
    }

    let participation;
    if (existing && existing.status === "Cancelled") {
      // Re-join after a previous cancellation
      existing.status = "Joined";
      existing.joinedDate = new Date();
      existing.completedDate = null;
      existing.pointsEarned = 0;
      participation = await existing.save();
    } else {
      participation = await Participation.create({ employeeId, activityId });
    }

    activity.participants += 1;
    await activity.save();

    res.status(201).json({ success: true, message: "Joined activity successfully", data: participation });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ success: false, message: "Employee has already joined this activity" });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /participation/:employeeId
exports.getParticipationByEmployee = async (req, res) => {
  try {
    const { employeeId } = req.params;
    if (!isValidId(employeeId)) return res.status(400).json({ success: false, message: "Invalid employee id" });

    const records = await Participation.find({ employeeId }).populate("activityId");
    res.status(200).json({ success: true, count: records.length, data: records });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /participation/:id  { action: "cancel" | "complete" }
exports.updateParticipation = async (req, res) => {
  try {
    const { id } = req.params;
    const { action } = req.body;
    if (!isValidId(id)) return res.status(400).json({ success: false, message: "Invalid participation id" });
    if (!["cancel", "complete"].includes(action)) {
      return res.status(400).json({ success: false, message: "action must be 'cancel' or 'complete'" });
    }

    const participation = await Participation.findById(id);
    if (!participation) return res.status(404).json({ success: false, message: "Participation record not found" });

    if (action === "cancel") {
      if (participation.status !== "Joined") {
        return res.status(400).json({ success: false, message: "Only a joined activity can be cancelled" });
      }
      participation.status = "Cancelled";
      await participation.save();

      await Activity.findByIdAndUpdate(participation.activityId, { $inc: { participants: -1 } });

      return res.status(200).json({ success: true, message: "Participation cancelled successfully", data: participation });
    }

    // action === "complete"
    if (participation.status !== "Joined") {
      return res.status(400).json({ success: false, message: "Cannot complete activity unless joined" });
    }

    const activity = await Activity.findById(participation.activityId);
    if (!activity) return res.status(404).json({ success: false, message: "Activity not found" });

    const employee = await Employee.findById(participation.employeeId);
    if (!employee) return res.status(404).json({ success: false, message: "Employee not found" });

    // ---- core business logic: complete -> award XP -> check badges -> update leaderboard ----
    const xpEarned = activity.pointsAwarded;

    participation.status = "Completed";
    participation.completedDate = new Date();
    participation.pointsEarned = xpEarned;

    employee.xp += xpEarned;
    employee.totalPoints += xpEarned;

    const newlyUnlocked = await checkAndAssignBadges(employee);

    await Promise.all([participation.save(), employee.save()]);

    // Leaderboard is derived live from Employee.xp, so recompute ranks
    await recalculateRanks();

    res.status(200).json({
      success: true,
      message: "Activity completed successfully",
      xpEarned,
      badgeUnlocked: newlyUnlocked.length ? newlyUnlocked[newlyUnlocked.length - 1].badgeName : null,
      badgesUnlocked: newlyUnlocked.map((b) => b.badgeName),
      data: participation,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Recomputes and persists the `rank` field on every employee based on XP desc.
async function recalculateRanks() {
  const employees = await Employee.find().sort({ xp: -1 });
  const bulkOps = employees.map((emp, index) => ({
    updateOne: { filter: { _id: emp._id }, update: { rank: index + 1 } },
  }));
  if (bulkOps.length) await Employee.bulkWrite(bulkOps);
}
exports.recalculateRanks = recalculateRanks;

// =========================================================
// DASHBOARD
// =========================================================

// GET /dashboard/social
exports.getSocialDashboard = async (req, res) => {
  try {
    const [totalActivities, completedActivities, activeEmployees, xpAgg, topEmployee, departmentAgg] =
      await Promise.all([
        Activity.countDocuments(),
        Activity.countDocuments({ status: "Completed" }),
        Employee.countDocuments({ xp: { $gt: 0 } }),
        Employee.aggregate([{ $group: { _id: null, totalXP: { $sum: "$xp" } } }]),
        Employee.findOne().sort({ xp: -1 }).select("name department xp badgeCount"),
        Participation.aggregate([
          { $match: { status: "Completed" } },
          {
            $lookup: {
              from: "employees",
              localField: "employeeId",
              foreignField: "_id",
              as: "employee",
            },
          },
          { $unwind: "$employee" },
          { $group: { _id: "$employee.department", count: { $sum: 1 } } },
          { $sort: { count: -1 } },
          { $limit: 1 },
        ]),
      ]);

    res.status(200).json({
      success: true,
      data: {
        totalActivities,
        completedActivities,
        activeEmployees,
        totalXPAwarded: xpAgg[0]?.totalXP || 0,
        mostActiveDepartment: departmentAgg[0]?._id || null,
        topEmployee: topEmployee || null,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
