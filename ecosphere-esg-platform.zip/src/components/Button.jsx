import "./Button.css";

/**
 * variant: "primary" | "secondary" | "outline" | "ghost"
 * size: "md" | "sm"
 */
export default function Button({
  children,
  icon: Icon,
  variant = "primary",
  size = "md",
  className = "",
  ...rest
}) {
  return (
    <button className={`btn btn--${variant} btn--${size} ${className}`} {...rest}>
      {Icon && <Icon size={size === "sm" ? 15 : 17} />}
      {children}
    </button>
  );
}
