import "./Table.css";

const statusToneMap = {
  "On Track": "success",
  Active: "success",
  Completed: "success",
  "At Risk": "warning",
  Ongoing: "info",
  "Under Review": "info",
  "Pending Approval": "warning",
  Upcoming: "info",
  "Non-Compliant": "danger",
};

export function StatusPill({ status }) {
  const tone = statusToneMap[status] || "neutral";
  return <span className={`status-pill status-pill--${tone}`}>{status}</span>;
}

/**
 * columns: [{ key, label, render?(row) }]
 * rows: array of objects
 */
export default function Table({ columns, rows, emptyLabel = "No records found." }) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key}>{col.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 && (
            <tr>
              <td colSpan={columns.length} className="table-empty">
                {emptyLabel}
              </td>
            </tr>
          )}
          {rows.map((row, i) => (
            <tr key={row.id ?? i}>
              {columns.map((col) => (
                <td key={col.key}>{col.render ? col.render(row) : row[col.key]}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
