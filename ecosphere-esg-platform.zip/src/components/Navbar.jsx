import { LuMenu, LuBell, LuSearch, LuChevronDown } from "react-icons/lu";
import { currentUser } from "../data/employees";
import "./Navbar.css";

export default function Navbar({ title, onMenuClick }) {
  return (
    <header className="navbar">
      <div className="navbar-left">
        <button className="navbar-menu-btn" onClick={onMenuClick} aria-label="Open menu">
          <LuMenu size={20} />
        </button>
        <h2 className="navbar-title">{title}</h2>
      </div>

      <div className="navbar-right">
        <div className="navbar-search">
          <LuSearch size={16} />
          <input type="text" placeholder="Search metrics, reports, policies..." />
        </div>

        <button className="navbar-icon-btn" aria-label="Notifications">
          <LuBell size={18} />
          <span className="navbar-dot" />
        </button>

        <div className="navbar-user">
          <span className="navbar-avatar">{currentUser.avatar}</span>
          <div className="navbar-user-meta">
            <span className="navbar-user-name">{currentUser.name}</span>
            <span className="navbar-user-role">{currentUser.role}</span>
          </div>
          <LuChevronDown size={16} className="navbar-user-caret" />
        </div>
      </div>
    </header>
  );
}
