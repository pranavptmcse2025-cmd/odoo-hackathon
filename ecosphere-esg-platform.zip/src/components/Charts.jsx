import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Line, Bar, Pie } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler
);

const fontFamily = "Inter, sans-serif";

const baseGrid = {
  color: "#eef1f0",
};

const baseTicks = {
  color: "#8a9490",
  font: { family: fontFamily, size: 11 },
};

export function LineChart({ data, height = 260, showLegend = false }) {
  return (
    <div style={{ height }}>
      <Line
        data={data}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: "index", intersect: false },
          plugins: {
            legend: { display: showLegend, labels: { font: { family: fontFamily, size: 12 }, usePointStyle: true } },
            tooltip: {
              backgroundColor: "#0f2418",
              padding: 10,
              cornerRadius: 8,
              titleFont: { family: fontFamily },
              bodyFont: { family: fontFamily },
            },
          },
          scales: {
            x: { grid: { display: false }, ticks: baseTicks },
            y: { grid: baseGrid, ticks: baseTicks, beginAtZero: false },
          },
        }}
      />
    </div>
  );
}

export function BarChart({ data, height = 260, showLegend = false, stacked = false }) {
  return (
    <div style={{ height }}>
      <Bar
        data={data}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: showLegend, labels: { font: { family: fontFamily, size: 12 }, usePointStyle: true } },
            tooltip: {
              backgroundColor: "#0f2418",
              padding: 10,
              cornerRadius: 8,
              titleFont: { family: fontFamily },
              bodyFont: { family: fontFamily },
            },
          },
          scales: {
            x: { grid: { display: false }, ticks: baseTicks, stacked },
            y: { grid: baseGrid, ticks: baseTicks, stacked },
          },
        }}
      />
    </div>
  );
}

export function PieChart({ data, height = 260 }) {
  return (
    <div style={{ height }}>
      <Pie
        data={data}
        options={{
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: "bottom",
              labels: { font: { family: fontFamily, size: 12 }, usePointStyle: true, padding: 16 },
            },
            tooltip: {
              backgroundColor: "#0f2418",
              padding: 10,
              cornerRadius: 8,
              titleFont: { family: fontFamily },
              bodyFont: { family: fontFamily },
            },
          },
        }}
      />
    </div>
  );
}

export const chartPalette = {
  primary: "#16a34a",
  secondary: "#22c55e",
  mint: "#86efac",
  slate: "#94a3b8",
  amber: "#f59e0b",
  blue: "#3b82f6",
  violet: "#8b5cf6",
  rose: "#f43f5e",
};
