import { NavLink } from "react-router-dom";
import {
  LuLayoutDashboard,
  LuLeaf,
  LuUsers,
  LuScale,
  LuFileChartColumn,
  LuTrophy,
  LuSettings,
  LuX,
  LuSprout,
} from "react-icons/lu";
import "./Sidebar.css";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LuLayoutDashboard },
  { to: "/environmental", label: "Environmental", icon: LuLeaf },
  { to: "/social", label: "Social", icon: LuUsers },
  { to: "/governance", label: "Governance", icon: LuScale },
  { to: "/reports", label: "Reports", icon: LuFileChartColumn },
  { to: "/leaderboard", label: "Leaderboard", icon: LuTrophy },
  { to: "/settings", label: "Settings", icon: LuSettings },
];

export default function Sidebar({ open, onClose }) {
  return (
    <>
      {open && <div className="sidebar-scrim" onClick={onClose} />}
      <aside className={`sidebar ${open ? "sidebar--open" : ""}`}>
        <div className="sidebar-brand">
          <span className="sidebar-brand-mark">
            <LuSprout size={20} />
          </span>
          <span className="sidebar-brand-name">
            Eco<strong>Sphere</strong>
          </span>
          <button className="sidebar-close" onClick={onClose} aria-label="Close menu">
            <LuX size={18} />
          </button>
        </div>

        <nav className="sidebar-nav">
          <span className="sidebar-nav-label">Menu</span>
          {navItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) => `sidebar-link ${isActive ? "sidebar-link--active" : ""}`}
              onClick={onClose}
            >
              <Icon size={18} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-score">
            <span className="sidebar-score-label">Overall ESG Score</span>
            <span className="sidebar-score-value">78<small>/100</small></span>
            <div className="sidebar-score-bar">
              <div className="sidebar-score-bar-fill" style={{ width: "78%" }} />
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
