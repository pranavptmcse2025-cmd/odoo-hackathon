import "./Footer.css";

export default function Footer() {
  return (
    <footer className="app-footer">
      <span>© {new Date().getFullYear()} EcoSphere. All rights reserved.</span>
      <span className="app-footer-links">
        <a href="#!">Privacy</a>
        <a href="#!">Terms</a>
        <a href="#!">Support</a>
      </span>
    </footer>
  );
}
