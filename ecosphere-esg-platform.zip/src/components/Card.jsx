import "./Card.css";

/**
 * Generic surface card. Compose with StatCard / ChartCard for common patterns.
 */
export default function Card({ children, className = "", padded = true, ...rest }) {
  return (
    <div className={`card ${padded ? "card--padded" : ""} ${className}`} {...rest}>
      {children}
    </div>
  );
}

/**
 * KPI stat card used across top-of-page metrics.
 * trend: "up" | "down" | "flat"
 */
export function StatCard({ icon: Icon, label, value, change, trend = "up", accent = "primary" }) {
  return (
    <Card className={`stat-card stat-card--${accent}`}>
      <div className="stat-card-top">
        <span className="stat-card-icon">
          <Icon size={20} />
        </span>
        {change && (
          <span className={`stat-card-change stat-card-change--${trend}`}>
            {change}
          </span>
        )}
      </div>
      <span className="stat-card-value mono">{value}</span>
      <span className="stat-card-label">{label}</span>
    </Card>
  );
}

/**
 * Wrapper for chart panels with a consistent header.
 */
export function ChartCard({ title, subtitle, action, children, className = "" }) {
  return (
    <Card className={`chart-card ${className}`}>
      <div className="chart-card-header">
        <div>
          <h3 className="chart-card-title">{title}</h3>
          {subtitle && <p className="chart-card-subtitle">{subtitle}</p>}
        </div>
        {action}
      </div>
      <div className="chart-card-body">{children}</div>
    </Card>
  );
}
