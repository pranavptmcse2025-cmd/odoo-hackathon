import { useState } from "react";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function Layout({ title, children }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="app-shell">
      <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <div className="main-area">
        <Navbar title={title} onMenuClick={() => setMenuOpen(true)} />
        <div className="page-content">{children}</div>
        <Footer />
      </div>
    </div>
  );
}
