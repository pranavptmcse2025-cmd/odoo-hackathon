// Mock carbon & environmental data — swap for API calls later
export const monthlyEmissionTrend = [
  { month: "Jan", emission: 420, target: 400 },
  { month: "Feb", emission: 405, target: 395 },
  { month: "Mar", emission: 390, target: 390 },
  { month: "Apr", emission: 378, target: 385 },
  { month: "May", emission: 360, target: 380 },
  { month: "Jun", emission: 345, target: 375 },
  { month: "Jul", emission: 330, target: 370 },
  { month: "Aug", emission: 320, target: 365 },
  { month: "Sep", emission: 305, target: 360 },
  { month: "Oct", emission: 298, target: 355 },
  { month: "Nov", emission: 286, target: 350 },
  { month: "Dec", emission: 270, target: 345 },
];

export const departmentEmission = [
  { department: "Manufacturing", current: 145, target: 120, status: "At Risk" },
  { department: "Logistics", current: 98, target: 100, status: "On Track" },
  { department: "IT & Operations", current: 32, target: 40, status: "On Track" },
  { department: "R&D", current: 54, target: 50, status: "At Risk" },
  { department: "Facilities", current: 41, target: 45, status: "On Track" },
  { department: "Sales & Marketing", current: 18, target: 20, status: "On Track" },
];

export const environmentalSummary = {
  totalEmission: "1,842 tCO₂e",
  monthlyEmission: "270 tCO₂e",
  carbonTarget: "1,600 tCO₂e",
  reductionPercent: "35.7%",
};
