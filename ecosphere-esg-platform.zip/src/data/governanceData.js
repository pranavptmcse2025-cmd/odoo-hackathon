// Mock governance data
export const governanceSummary = {
  policies: 34,
  audits: 8,
  complianceIssues: 3,
  pendingReviews: 6,
};

export const governanceTable = [
  { policy: "Anti-Bribery & Corruption Policy", department: "Finance", status: "Active", dueDate: "01 Aug 2026" },
  { policy: "Data Privacy & Protection Policy", department: "IT & Operations", status: "Under Review", dueDate: "15 Jul 2026" },
  { policy: "Supplier Code of Conduct", department: "Procurement", status: "Active", dueDate: "22 Sep 2026" },
  { policy: "Whistleblower Protection Policy", department: "HR", status: "Active", dueDate: "10 Oct 2026" },
  { policy: "Board Diversity Policy", department: "Executive", status: "Pending Approval", dueDate: "30 Jul 2026" },
  { policy: "Health & Safety Compliance Policy", department: "Manufacturing", status: "Non-Compliant", dueDate: "05 Jul 2026" },
];
