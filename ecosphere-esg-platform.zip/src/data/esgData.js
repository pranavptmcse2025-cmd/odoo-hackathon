// Mock top-level ESG data used across Dashboard & Reports
export const esgOverview = {
  esgScore: 78,
  esgScoreChange: "+4.2%",
  carbonEmission: "270 tCO₂e",
  carbonEmissionChange: "-6.8%",
  csrActivities: 12,
  csrActivitiesChange: "+3",
  complianceScore: "92%",
  complianceScoreChange: "+1.5%",
};

export const esgScoreTrend = {
  labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
  environmental: [62, 65, 68, 70, 73, 75, 79],
  social: [70, 71, 74, 76, 77, 78, 80],
  governance: [80, 81, 82, 83, 85, 86, 88],
};

export const recentActivities = [
  { id: 1, text: "Manufacturing unit reduced emissions by 8% this month", time: "2 hours ago", type: "environmental" },
  { id: 2, text: "132 employees joined the Blood Donation Camp", time: "5 hours ago", type: "social" },
  { id: 3, text: "Q2 compliance audit completed with no major findings", time: "1 day ago", type: "governance" },
  { id: 4, text: "New supplier code of conduct policy published", time: "2 days ago", type: "governance" },
  { id: 5, text: "Solar panel installation completed at Facility B", time: "3 days ago", type: "environmental" },
];

export const upcomingGoals = [
  { id: 1, title: "Reduce carbon emission by 40% YoY", deadline: "Dec 2026", progress: 68 },
  { id: 2, title: "Achieve zero workplace safety incidents", deadline: "Sep 2026", progress: 84 },
  { id: 3, title: "100% supplier ESG audit coverage", deadline: "Nov 2026", progress: 52 },
  { id: 4, title: "Plant 10,000 trees company-wide", deadline: "Oct 2026", progress: 41 },
];
