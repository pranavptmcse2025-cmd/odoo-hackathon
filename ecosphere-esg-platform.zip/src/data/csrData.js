// Mock CSR & social initiative data
export const csrActivities = [
  {
    id: 1,
    title: "Tree Plantation Drive",
    date: "12 Jun 2026",
    participants: 84,
    points: 420,
    status: "Completed",
    icon: "tree",
  },
  {
    id: 2,
    title: "Beach Cleanup Marathon",
    date: "28 Jun 2026",
    participants: 56,
    points: 310,
    status: "Completed",
    icon: "wave",
  },
  {
    id: 3,
    title: "Blood Donation Camp",
    date: "05 Jul 2026",
    participants: 132,
    points: 640,
    status: "Ongoing",
    icon: "droplet",
  },
  {
    id: 4,
    title: "Education Drive for Kids",
    date: "20 Jul 2026",
    participants: 47,
    points: 260,
    status: "Upcoming",
    icon: "book",
  },
];

export const csrParticipation = {
  labels: ["Tree Plantation", "Beach Cleanup", "Blood Donation", "Education Drive"],
  data: [84, 56, 132, 47],
};
