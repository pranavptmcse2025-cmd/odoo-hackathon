// Mock employee data used for leaderboard & profile
export const currentUser = {
  name: "Ananya Rao",
  role: "ESG Program Manager",
  email: "ananya.rao@ecosphere.io",
  avatar: "AR",
  department: "Sustainability",
};

export const leaderboard = [
  { rank: 1, name: "Ananya Rao", department: "Sustainability", xp: 3840, badges: ["🌱 Green Champion", "🏆 Top Contributor"] },
  { rank: 2, name: "Rahul Mehta", department: "Operations", xp: 3620, badges: ["♻️ Recycler", "🌍 Eco Hero"] },
  { rank: 3, name: "Priya Nair", department: "HR", xp: 3410, badges: ["🩸 Life Saver", "📚 Educator"] },
  { rank: 4, name: "Karthik Iyer", department: "Manufacturing", xp: 3105, badges: ["🌱 Green Champion"] },
  { rank: 5, name: "Sneha Kapoor", department: "Marketing", xp: 2980, badges: ["🌍 Eco Hero"] },
  { rank: 6, name: "Vikram Singh", department: "Logistics", xp: 2750, badges: ["♻️ Recycler"] },
  { rank: 7, name: "Divya Menon", department: "Finance", xp: 2590, badges: ["📚 Educator"] },
  { rank: 8, name: "Arjun Reddy", department: "IT & Operations", xp: 2410, badges: ["🌱 Green Champion"] },
];
