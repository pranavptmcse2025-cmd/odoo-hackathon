import { useState } from "react";
import { LuUser, LuBell, LuPalette, LuGlobe, LuCheck } from "react-icons/lu";
import Layout from "../../components/Layout";
import Card from "../../components/Card";
import Button from "../../components/Button";
import { currentUser } from "../../data/employees";
import "./Settings.css";

export default function Settings() {
  const [profile, setProfile] = useState({ name: currentUser.name, email: currentUser.email, department: currentUser.department });
  const [notifications, setNotifications] = useState({ email: true, push: true, weeklyDigest: false, complianceAlerts: true });
  const [theme, setTheme] = useState("light");
  const [language, setLanguage] = useState("English");
  const [saved, setSaved] = useState(false);

  const handleProfileChange = (e) => setProfile((p) => ({ ...p, [e.target.name]: e.target.value }));
  const toggleNotification = (key) => setNotifications((n) => ({ ...n, [key]: !n[key] }));

  const handleSave = (e) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <Layout title="Settings">
      <div className="page-header">
        <div>
          <span className="eyebrow">Preferences</span>
          <h1>Account Settings</h1>
          <p className="subtitle">Manage your profile, notifications, and workspace preferences.</p>
        </div>
        <Button icon={LuCheck} onClick={handleSave}>{saved ? "Saved!" : "Save Changes"}</Button>
      </div>

      <div className="settings-grid">
        <Card className="settings-card">
          <div className="settings-card-header">
            <span className="settings-icon"><LuUser size={18} /></span>
            <div>
              <h3>Profile</h3>
              <p>Your personal and organizational details</p>
            </div>
          </div>
          <div className="settings-field-grid">
            <label className="field">
              <span className="field-label">Full name</span>
              <div className="field-input"><input name="name" value={profile.name} onChange={handleProfileChange} /></div>
            </label>
            <label className="field">
              <span className="field-label">Email</span>
              <div className="field-input"><input name="email" value={profile.email} onChange={handleProfileChange} /></div>
            </label>
            <label className="field">
              <span className="field-label">Department</span>
              <div className="field-input"><input name="department" value={profile.department} onChange={handleProfileChange} /></div>
            </label>
          </div>
        </Card>

        <Card className="settings-card">
          <div className="settings-card-header">
            <span className="settings-icon"><LuBell size={18} /></span>
            <div>
              <h3>Notifications</h3>
              <p>Choose what updates you want to receive</p>
            </div>
          </div>
          <div className="toggle-list">
            {[
              { key: "email", label: "Email notifications" },
              { key: "push", label: "Push notifications" },
              { key: "weeklyDigest", label: "Weekly ESG digest" },
              { key: "complianceAlerts", label: "Compliance alerts" },
            ].map((item) => (
              <div className="toggle-row" key={item.key}>
                <span>{item.label}</span>
                <button
                  className={`toggle-switch ${notifications[item.key] ? "toggle-switch--on" : ""}`}
                  onClick={() => toggleNotification(item.key)}
                  aria-pressed={notifications[item.key]}
                >
                  <span className="toggle-knob" />
                </button>
              </div>
            ))}
          </div>
        </Card>

        <Card className="settings-card">
          <div className="settings-card-header">
            <span className="settings-icon"><LuPalette size={18} /></span>
            <div>
              <h3>Theme</h3>
              <p>Choose how EcoSphere looks for you</p>
            </div>
          </div>
          <div className="theme-options">
            {["light", "dark", "system"].map((t) => (
              <button
                key={t}
                className={`theme-option ${theme === t ? "theme-option--active" : ""}`}
                onClick={() => setTheme(t)}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>
        </Card>

        <Card className="settings-card">
          <div className="settings-card-header">
            <span className="settings-icon"><LuGlobe size={18} /></span>
            <div>
              <h3>Language</h3>
              <p>Set your preferred display language</p>
            </div>
          </div>
          <div className="settings-field-grid">
            <label className="field">
              <span className="field-label">Display language</span>
              <div className="field-input">
                <select value={language} onChange={(e) => setLanguage(e.target.value)}>
                  <option>English</option>
                  <option>Hindi</option>
                  <option>Spanish</option>
                  <option>French</option>
                  <option>German</option>
                </select>
              </div>
            </label>
          </div>
        </Card>
      </div>
    </Layout>
  );
}
