import { LuCloudDrizzle, LuCalendarDays, LuTarget, LuTrendingDown } from "react-icons/lu";
import Layout from "../../components/Layout";
import { StatCard, ChartCard } from "../../components/Card";
import Table, { StatusPill } from "../../components/Table";
import { LineChart, BarChart, chartPalette } from "../../components/Charts";
import { monthlyEmissionTrend, departmentEmission, environmentalSummary } from "../../data/carbonData";
import "./Environmental.css";

export default function Environmental() {
  const trendData = {
    labels: monthlyEmissionTrend.map((d) => d.month),
    datasets: [
      {
        label: "Emission (tCO₂e)",
        data: monthlyEmissionTrend.map((d) => d.emission),
        borderColor: chartPalette.primary,
        backgroundColor: "rgba(22, 163, 74, 0.12)",
        fill: true,
        tension: 0.4,
        pointRadius: 0,
        pointHoverRadius: 5,
        borderWidth: 2.5,
      },
      {
        label: "Target",
        data: monthlyEmissionTrend.map((d) => d.target),
        borderColor: chartPalette.amber,
        borderDash: [5, 5],
        fill: false,
        tension: 0.4,
        pointRadius: 0,
        borderWidth: 2,
      },
    ],
  };

  const deptData = {
    labels: departmentEmission.map((d) => d.department),
    datasets: [
      { label: "Current (tCO₂e)", data: departmentEmission.map((d) => d.current), backgroundColor: chartPalette.primary, borderRadius: 6 },
      { label: "Target (tCO₂e)", data: departmentEmission.map((d) => d.target), backgroundColor: "#c7e9d3", borderRadius: 6 },
    ],
  };

  const columns = [
    { key: "department", label: "Department" },
    { key: "current", label: "Current", render: (r) => `${r.current} tCO₂e` },
    { key: "target", label: "Target", render: (r) => `${r.target} tCO₂e` },
    { key: "status", label: "Status", render: (r) => <StatusPill status={r.status} /> },
  ];

  return (
    <Layout title="Environmental">
      <div className="page-header">
        <div>
          <span className="eyebrow">Environmental Pillar</span>
          <h1>Emissions &amp; Resource Impact</h1>
          <p className="subtitle">Monitor carbon output against reduction targets across the organization.</p>
        </div>
      </div>

      <div className="grid-4">
        <StatCard icon={LuCloudDrizzle} label="Total Emission" value={environmentalSummary.totalEmission} change="-4.1%" trend="down" accent="primary" />
        <StatCard icon={LuCalendarDays} label="Monthly Emission" value={environmentalSummary.monthlyEmission} change="-6.8%" trend="down" accent="info" />
        <StatCard icon={LuTarget} label="Carbon Target" value={environmentalSummary.carbonTarget} change="On Track" trend="flat" accent="warning" />
        <StatCard icon={LuTrendingDown} label="Reduction %" value={environmentalSummary.reductionPercent} change="+2.3%" trend="up" accent="primary" />
      </div>

      <div className="grid-2 section-block">
        <ChartCard title="Monthly Carbon Trend" subtitle="Actual emission vs annual target (tCO₂e)">
          <LineChart data={trendData} showLegend />
        </ChartCard>
        <ChartCard title="Department Emission" subtitle="Current output vs department targets">
          <BarChart data={deptData} showLegend />
        </ChartCard>
      </div>

      <div className="section-block">
        <ChartCard title="Department Breakdown" subtitle="Emission status by department">
          <Table columns={columns} rows={departmentEmission} />
        </ChartCard>
      </div>
    </Layout>
  );
}
