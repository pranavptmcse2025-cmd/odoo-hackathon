import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LuMail, LuLock, LuEye, LuEyeOff, LuSprout, LuLeaf, LuUsers, LuScale } from "react-icons/lu";
import Button from "../../components/Button";
import "./Login.css";

export default function Login() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ email: "", password: "", remember: true });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === "checkbox" ? checked : value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      setError("Please enter both email and password to continue.");
      return;
    }
    setError("");
    // No backend — mock auth, just proceed to dashboard.
    navigate("/dashboard");
  };

  return (
    <div className="login-page">
      <div className="login-panel">
        <div className="login-brand">
          <span className="login-brand-mark">
            <LuSprout size={22} />
          </span>
          <span className="login-brand-name">
            Eco<strong>Sphere</strong>
          </span>
        </div>

        <div className="login-form-wrap">
          <span className="eyebrow">Welcome back</span>
          <h1>Sign in to your workspace</h1>
          <p className="login-sub">Track, manage, and report your ESG performance in one place.</p>

          <form className="login-form" onSubmit={handleSubmit}>
            {error && <div className="login-error">{error}</div>}

            <label className="field">
              <span className="field-label">Email address</span>
              <div className="field-input">
                <LuMail size={17} />
                <input
                  type="email"
                  name="email"
                  placeholder="you@company.com"
                  value={form.email}
                  onChange={handleChange}
                  autoComplete="email"
                />
              </div>
            </label>

            <label className="field">
              <span className="field-label">Password</span>
              <div className="field-input">
                <LuLock size={17} />
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={handleChange}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="field-toggle"
                  onClick={() => setShowPassword((s) => !s)}
                  aria-label="Toggle password visibility"
                >
                  {showPassword ? <LuEyeOff size={16} /> : <LuEye size={16} />}
                </button>
              </div>
            </label>

            <div className="login-row">
              <label className="checkbox-field">
                <input type="checkbox" name="remember" checked={form.remember} onChange={handleChange} />
                <span>Remember me</span>
              </label>
              <a href="#!" className="login-forgot">Forgot password?</a>
            </div>

            <Button type="submit" className="login-submit">Log In</Button>
          </form>

          <p className="login-footnote">
            Demo build — enter any email &amp; password to explore the dashboard.
          </p>
        </div>
      </div>

      <div className="login-showcase">
        <div className="login-showcase-content">
          <span className="eyebrow eyebrow--light">Sustainability, quantified</span>
          <h2>See your organization's Environmental, Social &amp; Governance impact — in real time.</h2>
          <div className="login-showcase-stats">
            <div className="showcase-stat">
              <LuLeaf size={18} />
              <div>
                <strong>270 tCO₂e</strong>
                <span>Emission this month</span>
              </div>
            </div>
            <div className="showcase-stat">
              <LuUsers size={18} />
              <div>
                <strong>12 drives</strong>
                <span>CSR activities running</span>
              </div>
            </div>
            <div className="showcase-stat">
              <LuScale size={18} />
              <div>
                <strong>92%</strong>
                <span>Compliance score</span>
              </div>
            </div>
          </div>
        </div>
        <div className="login-showcase-glow" />
      </div>
    </div>
  );
}
