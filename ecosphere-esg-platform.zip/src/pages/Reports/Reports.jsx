import { useState } from "react";
import { LuFileDown, LuSheet, LuPlay } from "react-icons/lu";
import Layout from "../../components/Layout";
import Card, { ChartCard } from "../../components/Card";
import Button from "../../components/Button";
import { BarChart, chartPalette } from "../../components/Charts";
import { esgScoreTrend } from "../../data/esgData";
import "./Reports.css";

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const departments = ["All Departments", "Manufacturing", "Logistics", "IT & Operations", "R&D", "Facilities", "Sales & Marketing", "HR", "Finance"];
const years = ["2024", "2025", "2026"];

export default function Reports() {
  const [filters, setFilters] = useState({ month: "July", department: "All Departments", year: "2026" });
  const [generated, setGenerated] = useState(false);

  const handleChange = (e) => setFilters((f) => ({ ...f, [e.target.name]: e.target.value }));

  const summaryData = {
    labels: esgScoreTrend.labels,
    datasets: [
      { label: "Environmental", data: esgScoreTrend.environmental, backgroundColor: chartPalette.primary, borderRadius: 6 },
      { label: "Social", data: esgScoreTrend.social, backgroundColor: chartPalette.secondary, borderRadius: 6 },
      { label: "Governance", data: esgScoreTrend.governance, backgroundColor: chartPalette.mint, borderRadius: 6 },
    ],
  };

  return (
    <Layout title="Reports">
      <div className="page-header">
        <div>
          <span className="eyebrow">ESG Reporting</span>
          <h1>Generate &amp; Export Reports</h1>
          <p className="subtitle">Filter by period and department to compile a shareable ESG summary.</p>
        </div>
      </div>

      <Card className="report-filters">
        <div className="filter-field">
          <label>Month</label>
          <select name="month" value={filters.month} onChange={handleChange}>
            {months.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
        <div className="filter-field">
          <label>Department</label>
          <select name="department" value={filters.department} onChange={handleChange}>
            {departments.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div className="filter-field">
          <label>Year</label>
          <select name="year" value={filters.year} onChange={handleChange}>
            {years.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
        <div className="filter-actions">
          <Button icon={LuPlay} onClick={() => setGenerated(true)}>Generate Report</Button>
          <Button icon={LuFileDown} variant="outline" disabled={!generated}>Download PDF</Button>
          <Button icon={LuSheet} variant="outline" disabled={!generated}>Download Excel</Button>
        </div>
      </Card>

      {generated && (
        <div className="report-status">
          Report compiled for <strong>{filters.month} {filters.year}</strong> — {filters.department}. Ready to export.
        </div>
      )}

      <div className="section-block">
        <ChartCard title="Monthly ESG Summary" subtitle={`Score breakdown for ${filters.department} · ${filters.year}`}>
          <BarChart data={summaryData} showLegend height={300} />
        </ChartCard>
      </div>
    </Layout>
  );
}
