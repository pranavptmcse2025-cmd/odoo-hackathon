import { LuGauge, LuCloudDrizzle, LuHeartHandshake, LuShieldCheck, LuArrowUpRight, LuTarget } from "react-icons/lu";
import Layout from "../../components/Layout";
import Card, { StatCard, ChartCard } from "../../components/Card";
import ScoreGauge from "../../components/ScoreGauge";
import { LineChart, BarChart, PieChart, chartPalette } from "../../components/Charts";
import { esgOverview, esgScoreTrend, recentActivities, upcomingGoals } from "../../data/esgData";
import { monthlyEmissionTrend } from "../../data/carbonData";
import { csrParticipation } from "../../data/csrData";
import "./Dashboard.css";

export default function Dashboard() {
  const carbonLineData = {
    labels: monthlyEmissionTrend.map((d) => d.month),
    datasets: [
      {
        label: "Emission (tCO₂e)",
        data: monthlyEmissionTrend.map((d) => d.emission),
        borderColor: chartPalette.primary,
        backgroundColor: "rgba(22, 163, 74, 0.12)",
        fill: true,
        tension: 0.4,
        pointRadius: 0,
        pointHoverRadius: 5,
        borderWidth: 2.5,
      },
      {
        label: "Target",
        data: monthlyEmissionTrend.map((d) => d.target),
        borderColor: chartPalette.slate,
        borderDash: [5, 5],
        fill: false,
        tension: 0.4,
        pointRadius: 0,
        borderWidth: 2,
      },
    ],
  };

  const esgBarData = {
    labels: esgScoreTrend.labels,
    datasets: [
      { label: "Environmental", data: esgScoreTrend.environmental, backgroundColor: chartPalette.primary, borderRadius: 6 },
      { label: "Social", data: esgScoreTrend.social, backgroundColor: chartPalette.secondary, borderRadius: 6 },
      { label: "Governance", data: esgScoreTrend.governance, backgroundColor: chartPalette.mint, borderRadius: 6 },
    ],
  };

  const csrPieData = {
    labels: csrParticipation.labels,
    datasets: [
      {
        data: csrParticipation.data,
        backgroundColor: [chartPalette.primary, chartPalette.secondary, chartPalette.mint, chartPalette.slate],
        borderWidth: 0,
      },
    ],
  };

  return (
    <Layout title="Dashboard">
      <div className="page-header">
        <div>
          <span className="eyebrow">Overview</span>
          <h1>Good morning, Ananya 👋</h1>
          <p className="subtitle">Here's how EcoSphere is performing across all ESG pillars this month.</p>
        </div>
      </div>

      <div className="dash-hero grid-2">
        <Card className="dash-hero-card">
          <ScoreGauge score={esgOverview.esgScore} label="Overall ESG Score" />
          <div className="dash-hero-info">
            <span className="stat-card-change stat-card-change--up">
              <LuArrowUpRight size={13} style={{ marginRight: 4, verticalAlign: "-2px" }} />
              {esgOverview.esgScoreChange} vs last quarter
            </span>
            <p>
              EcoSphere's composite score blends environmental efficiency, social engagement, and
              governance integrity into a single benchmark. Keep momentum by focusing on
              departments flagged "At Risk" in the Environmental tab.
            </p>
          </div>
        </Card>

        <div className="grid-4 dash-stat-grid">
          <StatCard icon={LuGauge} label="ESG Score" value={esgOverview.esgScore} change={esgOverview.esgScoreChange} trend="up" accent="primary" />
          <StatCard icon={LuCloudDrizzle} label="Carbon Emission" value={esgOverview.carbonEmission} change={esgOverview.carbonEmissionChange} trend="down" accent="info" />
          <StatCard icon={LuHeartHandshake} label="CSR Activities" value={esgOverview.csrActivities} change={esgOverview.csrActivitiesChange} trend="up" accent="warning" />
          <StatCard icon={LuShieldCheck} label="Compliance Score" value={esgOverview.complianceScore} change={esgOverview.complianceScoreChange} trend="up" accent="primary" />
        </div>
      </div>

      <div className="grid-2 section-block">
        <ChartCard title="Carbon Emission Trend" subtitle="Actual vs target, monthly (tCO₂e)">
          <LineChart data={carbonLineData} showLegend />
        </ChartCard>
        <ChartCard title="CSR Participation" subtitle="Employees engaged by initiative">
          <PieChart data={csrPieData} />
        </ChartCard>
      </div>

      <div className="section-block">
        <ChartCard title="ESG Score Breakdown" subtitle="Environmental, Social & Governance — 7 month trend">
          <BarChart data={esgBarData} showLegend height={280} />
        </ChartCard>
      </div>

      <div className="grid-2 section-block">
        <ChartCard title="Recent Activities" subtitle="Latest updates across your organization">
          <ul className="activity-list">
            {recentActivities.map((a) => (
              <li key={a.id} className="activity-item">
                <span className={`activity-dot activity-dot--${a.type}`} />
                <div>
                  <p>{a.text}</p>
                  <span className="activity-time">{a.time}</span>
                </div>
              </li>
            ))}
          </ul>
        </ChartCard>

        <ChartCard title="Upcoming Goals" subtitle="Targets in progress this cycle">
          <ul className="goal-list">
            {upcomingGoals.map((g) => (
              <li key={g.id} className="goal-item">
                <div className="goal-item-top">
                  <span className="goal-icon"><LuTarget size={14} /></span>
                  <div className="goal-item-text">
                    <p>{g.title}</p>
                    <span className="goal-deadline">Due {g.deadline}</span>
                  </div>
                  <span className="goal-progress-value mono">{g.progress}%</span>
                </div>
                <div className="goal-progress-bar">
                  <div className="goal-progress-bar-fill" style={{ width: `${g.progress}%` }} />
                </div>
              </li>
            ))}
          </ul>
        </ChartCard>
      </div>
    </Layout>
  );
}
