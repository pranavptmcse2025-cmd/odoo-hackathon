import { LuTrophy, LuMedal } from "react-icons/lu";
import Layout from "../../components/Layout";
import Card from "../../components/Card";
import { leaderboard } from "../../data/employees";
import "./Leaderboard.css";

const medalColors = { 1: "#f0b429", 2: "#94a3b8", 3: "#c2793a" };

export default function Leaderboard() {
  const [first, second, third, ...rest] = leaderboard;

  return (
    <Layout title="Leaderboard">
      <div className="page-header">
        <div>
          <span className="eyebrow">Recognition</span>
          <h1>Sustainability Leaderboard</h1>
          <p className="subtitle">Top contributors ranked by ESG engagement XP this quarter.</p>
        </div>
      </div>

      <div className="podium">
        {[second, first, third].map((emp, i) => (
          <Card key={emp.rank} className={`podium-card podium-card--${emp.rank}`}>
            <span className="podium-rank" style={{ color: medalColors[emp.rank] }}>
              <LuTrophy size={emp.rank === 1 ? 26 : 20} />
            </span>
            <span className="podium-avatar">{emp.name.split(" ").map((n) => n[0]).join("")}</span>
            <h3>{emp.name}</h3>
            <span className="podium-dept">{emp.department}</span>
            <span className="podium-xp mono">{emp.xp.toLocaleString()} XP</span>
          </Card>
        ))}
      </div>

      <Card className="section-block leaderboard-table-card">
        <div className="leaderboard-table">
          <div className="leaderboard-row leaderboard-row--head">
            <span>Rank</span>
            <span>Employee</span>
            <span>Department</span>
            <span>XP</span>
            <span>Badges</span>
          </div>
          {leaderboard.map((emp) => (
            <div className="leaderboard-row" key={emp.rank}>
              <span className="rank-badge">
                {emp.rank <= 3 ? <LuMedal size={15} color={medalColors[emp.rank]} /> : null}
                #{emp.rank}
              </span>
              <span className="leaderboard-name">
                <span className="leaderboard-mini-avatar">{emp.name.split(" ").map((n) => n[0]).join("")}</span>
                {emp.name}
              </span>
              <span>{emp.department}</span>
              <span className="mono">{emp.xp.toLocaleString()}</span>
              <span className="leaderboard-badges">
                {emp.badges.map((b) => (
                  <span key={b} className="badge-pill">{b}</span>
                ))}
              </span>
            </div>
          ))}
        </div>
      </Card>
    </Layout>
  );
}
