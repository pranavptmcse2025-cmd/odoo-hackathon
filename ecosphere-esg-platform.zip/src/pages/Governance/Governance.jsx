import { LuFileText, LuClipboardCheck, LuTriangleAlert, LuHourglass } from "react-icons/lu";
import Layout from "../../components/Layout";
import { StatCard, ChartCard } from "../../components/Card";
import Table, { StatusPill } from "../../components/Table";
import { governanceSummary, governanceTable } from "../../data/governanceData";
import "./Governance.css";

export default function Governance() {
  const columns = [
    { key: "policy", label: "Policy" },
    { key: "department", label: "Department" },
    { key: "status", label: "Status", render: (r) => <StatusPill status={r.status} /> },
    { key: "dueDate", label: "Due Date" },
  ];

  return (
    <Layout title="Governance">
      <div className="page-header">
        <div>
          <span className="eyebrow">Governance Pillar</span>
          <h1>Policies, Audits &amp; Compliance</h1>
          <p className="subtitle">Stay ahead of regulatory obligations and internal policy reviews.</p>
        </div>
      </div>

      <div className="grid-4">
        <StatCard icon={LuFileText} label="Policies" value={governanceSummary.policies} change="+2 new" trend="up" accent="primary" />
        <StatCard icon={LuClipboardCheck} label="Audits" value={governanceSummary.audits} change="This quarter" trend="flat" accent="info" />
        <StatCard icon={LuTriangleAlert} label="Compliance Issues" value={governanceSummary.complianceIssues} change="-2 resolved" trend="down" accent="warning" />
        <StatCard icon={LuHourglass} label="Pending Reviews" value={governanceSummary.pendingReviews} change="Due this month" trend="flat" accent="primary" />
      </div>

      <div className="section-block">
        <ChartCard title="Policy Register" subtitle="Status and review timeline by department">
          <Table columns={columns} rows={governanceTable} />
        </ChartCard>
      </div>
    </Layout>
  );
}
