import { LuTreePine, LuWaves, LuDroplet, LuBookOpen, LuUsers, LuCalendarDays } from "react-icons/lu";
import Layout from "../../components/Layout";
import Card, { ChartCard } from "../../components/Card";
import { StatusPill } from "../../components/Table";
import { PieChart, chartPalette } from "../../components/Charts";
import { csrActivities, csrParticipation } from "../../data/csrData";
import "./Social.css";

const iconMap = {
  tree: LuTreePine,
  wave: LuWaves,
  droplet: LuDroplet,
  book: LuBookOpen,
};

export default function Social() {
  const csrPieData = {
    labels: csrParticipation.labels,
    datasets: [
      {
        data: csrParticipation.data,
        backgroundColor: [chartPalette.primary, chartPalette.secondary, chartPalette.blue, chartPalette.amber],
        borderWidth: 0,
      },
    ],
  };

  return (
    <Layout title="Social">
      <div className="page-header">
        <div>
          <span className="eyebrow">Social Pillar</span>
          <h1>CSR &amp; Community Engagement</h1>
          <p className="subtitle">Track participation and impact across employee-led initiatives.</p>
        </div>
      </div>

      <div className="grid-4">
        {csrActivities.map((activity) => {
          const Icon = iconMap[activity.icon] || LuUsers;
          return (
            <Card key={activity.id} className="csr-card">
              <div className="csr-card-icon">
                <Icon size={20} />
              </div>
              <h3 className="csr-card-title">{activity.title}</h3>
              <div className="csr-card-meta">
                <span><LuCalendarDays size={13} /> {activity.date}</span>
                <span><LuUsers size={13} /> {activity.participants} joined</span>
              </div>
              <div className="csr-card-footer">
                <span className="csr-card-points mono">+{activity.points} pts</span>
                <StatusPill status={activity.status} />
              </div>
            </Card>
          );
        })}
      </div>

      <div className="section-block">
        <ChartCard title="CSR Participation" subtitle="Employee engagement share by initiative" className="csr-chart-card">
          <PieChart data={csrPieData} height={300} />
        </ChartCard>
      </div>
    </Layout>
  );
}
